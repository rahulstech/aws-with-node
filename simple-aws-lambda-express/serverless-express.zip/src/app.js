const express = require('express');

const server = express();


server.use(express.json());

server.get('/',(req,res)=>{
    res.send('hello from server. this is the basic response for aws lambda with nodejs express');
});

server.post('/echo',  (req,res) => {
    const { name } = req.body;
    res.send(`Hello ${name} this is an echo endpoint on aws lambda nodejs express`)
});

server.get('/search', (req,res) => {
    const { country } = req.query;
    res.send(`your search result for country = ${country} from aws lambda nodejs express server`);
});
module.exports = { app: server };